def main():
    open("/path/to/mars.jpg")

if __name__ == '__main__':
    main()